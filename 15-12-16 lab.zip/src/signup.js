import React, {Component} from 'react';
import * as firebase from 'firebase';
import {Router, Route, indexRoute, hashHistory,browserHistory} from 'react-router'
const config = {
    apiKey: "AIzaSyBx94jQ75TTdDe9rUBjLJmF10-AcARM7YQ",
    authDomain: "form-sign-up-login.firebaseapp.com",
    databaseURL: "https://form-sign-up-login.firebaseio.com",
    storageBucket: "form-sign-up-login.appspot.com",
    messagingSenderId: "187144506554"
  };
  
  firebase.initializeApp(config);
//////////////////////////////////////////////////////////////////////////////////////////////////////////

const btnLogin = document.getElementById("btnLogin");
const btnSignUp = document.getElementById("btnSignUp");
const btnLogout = document.getElementById("btnLogout");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class SignUp extends Component{


btnSignUp1(){
  const email = document.getElementById("txtEmail").value;
    const pass = document.getElementById("txtPassword").value;
    const auth = firebase.auth();
    const promise = auth.createUserWithEmailAndPassword(email,pass);
    promise.then((user)=>{
        console.log(user)
hashHistory.replace("/Login");
    })
    return(
        promise.catch(e => console.log(e.message))
    )
    
}

    render(){
        return(
            <div className="container">

                          <h1 className="center">Sign Up</h1>
                
               <input type="text" placeholder='User Name' id= 'txtName'/>

                <input type="email" placeholder='Email' id= 'txtEmail'/>

                 <input type="password" placeholder='Password' id= 'txtPassword'/>

                 <button  className='btn ' id= 'btnSignUp'  onClick={this.btnSignUp1}>
                     SignUp
                 </button>


            </div>
        )
    }
}



export default SignUp