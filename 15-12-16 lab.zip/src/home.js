import React, {Component} from 'react'
import SignUp  from './signup';
import Login from './Login';
import * as firebase from 'firebase';
import {Router, Route, indexRoute, hashHistory,browserHistory} from 'react-router'


class Home extends Component{

componentDidMount(){
    const btnLogin = document.getElementById("btnLogin");
const btnSignUp = document.getElementById("btnSignUp");
const btnLogout = document.getElementById("btnLogout");
       firebase.auth().onAuthStateChanged(firebaseEmail => {
    if(firebaseEmail){
        console.log(firebaseEmail)
        btnLogout.classList.remove('hide')
      
    }
else{
    console.log(" logged out")
    btnLogout.classList.add('hide')

}
})
}

btnLogout1(){
    //  const auth = firebase.auth();
    // const promise = auth.signOut();
    // promise.then((email)=>{
    //     console.log(email)
    //     hashHistory.replace('/')
    // })
        firebase.auth().signOut();
        hashHistory.push('/');
    }

render(){
    return(
        <div className='container'>
             <button className='btn btn-action hide' id= 'btnLogout' onClick={this.btnLogout1} style={{position:"fixed",top:"5%",left:'90%',right:'10%',bottom:'100%'}}>
                  Logout
                 </button>
            <h1>HOME</h1>
        </div>
    )
}
}

export default Home