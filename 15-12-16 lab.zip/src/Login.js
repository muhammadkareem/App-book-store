import React,{Component} from 'react'
import * as firebase from 'firebase';
import Home from './home.js'
import {Router, Route, indexRoute, hashHistory} from 'react-router'







class Login extends Component {
    

componentDidMount(){
    const btnLogin = document.getElementById("btnLogin");
const btnSignUp = document.getElementById("btnSignUp");
       firebase.auth().onAuthStateChanged(firebaseEmail => {
    if(firebaseEmail){
        console.log(firebaseEmail)
      
      
    }
else{
    console.log("logged out")
  

}
})
}

btnLogin1(){
  const email = document.getElementById("txtEmail").value;
    const pass = document.getElementById("txtPassword").value;
    const auth = firebase.auth();
    const promise = auth.signInWithEmailAndPassword(email,pass);
    promise.then((user)=>{
        console.log(user)
        hashHistory.replace('/Home')
    })
    return(
        promise.then(user => console.log(user))
    
    )
}



    render(){
        return(
             <div className="container">

                          <h1 className="center">Login</h1>


                <input type="email" placeholder='Email' id= 'txtEmail'/>

                 <input type="password" placeholder='Password' id= 'txtPassword'/>

                 <button className='btn btn-action' id= 'btnLogin' onClick={this.btnLogin1}>
                 Login
                 </button>
 
                 {/*<button className='btn btn-action hide' id= 'btnLogout' onClick={this.btnLogout1}>
                  Logout
                 </button>*/}

            </div>
        )
    }
}

export default Login