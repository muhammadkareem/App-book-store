import React , {Component} from 'react';
import {Link} from 'react-router';
import SignUp  from './signup';
import Login from './Login';


class greeting extends Component{
    render(){
        return(
            <div className='container' style={{position:"fixed",top:"25%",left:'25%',right:'25%',bottom:'25%'}}>
                <h1>Home</h1>
                <Link to="/signup" className='btn'>Sign Up</Link>
                <Link to='/Login' className='btn'>Login</Link>
            </div>
        )
    }
} 

export default greeting