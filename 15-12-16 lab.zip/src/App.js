import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {Router, Route, indexRoute, hashHistory} from 'react-router'





import SignUp  from './signup';
import Login from './Login';
import greeting from './greeting';
import Home from './home.js'





ReactDOM.render(
<Router history={hashHistory}>
<Route path='/' component={greeting}/>
<Route component={greeting}/>
<Route path='/SignUp' component={SignUp}/>
<Route path='/Login' component={Login}/>
<Route path='/Home' component={Home}/>
   </Router>
,
    document.getElementById('app')
)